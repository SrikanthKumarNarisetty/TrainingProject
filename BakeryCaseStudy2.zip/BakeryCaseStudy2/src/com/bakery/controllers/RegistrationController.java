package com.bakery.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bakery.beans.RegistrationBean;
import com.bakery.daoimplementation.Registrationdaoimplementation;

/**
 * Servlet implementation class RegistrationController
 */
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext sc=getServletContext();
		RegistrationBean reg = new RegistrationBean();
		String fname=request.getParameter("Name");
		System.out.println(fname);
		String udob=request.getParameter("dob");
		System.out.println(udob);
		String uemail=request.getParameter("email");
		String ucontact=request.getParameter("contact");
		String uaddress=request.getParameter("address");
		String uname=request.getParameter("username");
		String upass=request.getParameter("password");	
		reg.setName(fname);
		reg.setDOB(udob);
		reg.setEmail(uemail);
		reg.setContact(ucontact);
		reg.setAddress(uaddress);
		reg.setUsername(uname);
		reg.setPassword(upass);
		Registrationdaoimplementation regimp = new Registrationdaoimplementation();
	boolean b1=regimp.insert(reg);
	if(b1)
	{
		sc.setAttribute("name", fname);
		sc.setAttribute("DOB", udob);
		sc.setAttribute("email", uemail);
		sc.setAttribute("contact", ucontact);
		sc.setAttribute("address", uaddress);
		sc.setAttribute("username", uname);
		sc.setAttribute("password", upass);
		
		RequestDispatcher rd=sc.getRequestDispatcher("/successreg.jsp");
		rd.forward(request, response);
	}
	else
	{
		RequestDispatcher rd=sc.getRequestDispatcher("/register.html");
		rd.forward(request, response);
	}
	}
	

	}


