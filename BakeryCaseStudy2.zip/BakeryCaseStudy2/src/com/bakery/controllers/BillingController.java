package com.bakery.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bakery.beans.BillingBean;
import com.bakery.daoimplementation.Billdaoimplementation;

/**
 * Servlet implementation class BillingController
 */
public class BillingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public BillingController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext sc=getServletContext();
		HttpSession session=request.getSession();  
		String Name=request.getParameter("Name");
		String Contact=request.getParameter("contact");
		String Address=request.getParameter("Address");
		String username=(String)session.getAttribute("username");
		session.setAttribute("uname",username );
		BillingBean bobj = new BillingBean();
		bobj.setBill_name(Name);
		bobj.setBill_contact(Contact);
		bobj.setBill_address(Address);
		bobj.setUsername(username);
		Billdaoimplementation billimp = new Billdaoimplementation();
		
		boolean b=billimp.bill_details(bobj);
		if(b)
		{
			RequestDispatcher rd=sc.getRequestDispatcher("/PrintBill.html");
			rd.forward(request, response);
		}
		else
		{
			RequestDispatcher rd=sc.getRequestDispatcher("/FailedOrder.jsp");
			rd.forward(request, response);
		}
		}
	}


