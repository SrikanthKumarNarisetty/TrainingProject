package com.bakery.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bakery.beans.ModifyItemBean;
import com.bakery.daoimplementation.ModifyImplementation;


/**
 * Servlet implementation class ModifyController
 */
public class ModifyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModifyController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext sc=getServletContext();
		response.setContentType("text/html");
		String itemid=request.getParameter("Itemid");
		int quantity=Integer.parseInt(request.getParameter("Quantity"));
		ModifyItemBean mobj = new ModifyItemBean();
		ModifyImplementation modifyimp=new ModifyImplementation();
		mobj.setItemid(itemid);
		mobj.setQuantity(quantity);
		
		boolean b=modifyimp.modify(mobj);
		System.out.println(b);
		if(b)
		{
	       RequestDispatcher rd=sc.getRequestDispatcher("/modify.jsp");
			rd.forward(request, response);
		}

		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
