/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bakery.controllers;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.bakery.beans.LoginBean;
import com.bakery.daoimplementation.Logindaoimplementation;

public class LoginController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	public void init( ){
        // no code
    }
public void service(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
	ServletContext sc=getServletContext();
	HttpSession session=request.getSession();  
	String uname=request.getParameter("userid");
	String upass=request.getParameter("password");
	System.out.println(uname);
	System.out.println(upass);
	 if(uname.equals("admin") && upass.equals("admin"))
	{
		RequestDispatcher rd=sc.getRequestDispatcher("/admin.jsp");
		rd.forward(request, response);
	}
	 else
	 {
		 LoginBean login = new LoginBean();
		 Logindaoimplementation loginimp=new Logindaoimplementation();
	login.setName(uname);
	login.setPassword(upass);
	boolean b=loginimp.validate(login);
	System.out.println(b);
	if(b)
	{
		session.setAttribute("username",uname);  
		session.setAttribute("password",upass);  
		sc.setAttribute("name", uname);
		sc.setAttribute("password", upass);
		RequestDispatcher rd=sc.getRequestDispatcher("/loginvalid.jsp");
		rd.forward(request, response);
	}
	else     
	{
		RequestDispatcher rd=sc.getRequestDispatcher("/logininvalid.jsp");
		rd.forward(request, response);
	}
	}
	 /*
 try{
	 
	 if(role.equals("user") || !role.equals("admin")){
		 LoginBean login = new LoginBean();
		 login.setName(userName);
		 login.setPassword(password);
		 Logindaoimplementation loginimp=new Logindaoimplementation();
  role=loginimp.validate(login);
  
	 if(role.equalsIgnoreCase("user")){
	 	System.out.println("inside");
	 HttpSession session = request.getSession();
	 session.setAttribute("username",userName);
	 RequestDispatcher rd = request.getRequestDispatcher("UserHome.jsp");
	 rd.forward(request, response);
	 }
	 
	 if( role.equalsIgnoreCase("invalid")){
	 RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
	 rd.forward(request, response);
	 }
	 }
	 else{
		 //( role.equalsIgnoreCase("admin")){
			 //out.println("")
			 if(userName.equals("admin") && password.equals("admin123")){
				 System.out.println(role);
			 		System.out.println(userName);
			 HttpSession session = request.getSession();
			 session.setAttribute("username",userName);
			 RequestDispatcher rd = request.getRequestDispatcher("AdminHome.jsp");
			 rd.forward(request, response);
		 	//}
	
	 }
			 else{
				 RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
				 rd.forward(request, response);
			 }
	 }
	 
} catch(ClassNotFoundException ce){
}
catch(SQLException se){
}

}
public void destory( ){

}*/
}
}
