package com.bakery.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bakery.beans.OrderItemsBean;
import com.bakery.daoimplementation.Orderdaoimplementation;

/**
 * Servlet implementation class OderItemsController
 */
public class OrderItemsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderItemsController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext sc=getServletContext();
		OrderItemsBean ord = new OrderItemsBean();

		int uquantity=Integer.parseInt(request.getParameter("Quantity"));
		System.out.println("quantity="+uquantity);
		String uname=request.getParameter("Itemname");
		System.out.println(uname);
		int uprice=Integer.parseInt(request.getParameter("Price"));
		System.out.println(uprice);
		
		ord.setItemname(uname);
		ord.setPrice(uprice);
		ord.setQuantity(uquantity);
		Orderdaoimplementation ordimp = new Orderdaoimplementation();
		boolean o=ordimp.order(ord);
		if(o)
		{
			RequestDispatcher rd=sc.getRequestDispatcher("/order.jsp");
			rd.forward(request, response);
			
		}
		else
		{
			RequestDispatcher rd=sc.getRequestDispatcher("/unplacedorder.jsp");
			rd.forward(request, response);
		}
		
	}
	}


