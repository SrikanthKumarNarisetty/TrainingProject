package com.bakery.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bakery.beans.AdminAddBean;
import com.bakery.daoimplementation.AdminAdddaoimplementation;


/**
 * Servlet implementation class AdminAddController
 */
public class AdminAddController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminAddController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext sc=getServletContext();
		response.setContentType("text/html");
		String itemid=request.getParameter("Itemid");
		String itemname=request.getParameter("Itemname");
		int price=Integer.parseInt(request.getParameter("Price"));
		int avail_qty=Integer.parseInt(request.getParameter("Avail_Qty"));
		AdminAddBean aobj = new AdminAddBean();
		aobj.setItemid(itemid);
		aobj.setItemname(itemname);
		aobj.setPrice(price);
		aobj.setAvail_quantity(avail_qty);
		AdminAdddaoimplementation additem=new AdminAdddaoimplementation();
		boolean b=additem.add(aobj);
		if(b)
		{
		  RequestDispatcher rd=sc.getRequestDispatcher("/add.jsp");
			rd.forward(request, response);
		}
		
		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
