package com.bakery.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bakery.beans.AddCartBean;
import com.bakery.beans.CartListBean;
import com.bakery.daoimplementation.Addcartdaoimplementation;
import com.bakery.daoimplementation.CartListdaoimplementation;

/**
 * Servlet implementation class AddCartController
 */
public class AddCartController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCartController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();  
		ServletContext sc=getServletContext();
		AddCartBean add = new AddCartBean();
		CartListBean ins = new CartListBean();
		String uitem_id=request.getParameter("Item_id");
		System.out.println(uitem_id);
		System.out.println("rama");
		int uquantity=Integer.parseInt(request.getParameter("Quantity"));
		String uname=request.getParameter("Itemname");
		int uprice=Integer.parseInt(request.getParameter("Price"));
		String username=(String)session.getAttribute("username");
		
		String s1=Integer.toString(uquantity);
		String s2=Integer.toString(uprice);
		
		request.setAttribute("name",uname);
		request.setAttribute("quantity",s1);
		request.setAttribute("price",s2);
		
		add.setItemid(uitem_id);
		add.setQuantity(uquantity);
		ins.setQuanity(uquantity);
		ins.setItemname(uname);
		ins.setPrice(uprice);
		ins.setUsername(username);
		Addcartdaoimplementation addimp = new Addcartdaoimplementation();
		boolean b1=addimp.chechForAvail(add);
		if(b1)
		{
			CartListdaoimplementation cartimp = new CartListdaoimplementation();
			boolean b2=cartimp.insert(ins);
			if(b2)
			{
			RequestDispatcher rd=sc.getRequestDispatcher("/Avail.jsp");
			rd.forward(request, response);
			
			}
			else
			{
				RequestDispatcher rd=sc.getRequestDispatcher("/Bihar_special.html");
				rd.forward(request, response);
			}
		}	
		else
		{
			RequestDispatcher rd=sc.getRequestDispatcher("/NotAvailable.jsp");
			rd.forward(request, response);
		}
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
