package com.bakery.daoimplementation;

import java.sql.Connection;

import java.sql.PreparedStatement;

import com.bakery.DBUtility.DBhelper;
import com.bakery.beans.AdminDeleteBean;
import com.bakery.interfaces.adminDeleteInterface;

public class AdminDeletedaoimplementation implements adminDeleteInterface{
	
	
	public boolean delete(AdminDeleteBean adb)
	{
		boolean b1=false;
		try
		{
			 Connection con=DBhelper.getConnection();
			 PreparedStatement stat=con.prepareStatement("delete from bak_item where item_id=?");
			// PreparedStatement stat1=con.prepareStatement("select * from bak_login where user_id=? and password=?");
			 stat.setString(1, adb.getItemid());
			
			 int rs=stat.executeUpdate();
			 System.out.println(adb.getItemid());
			 //boolean b=rs.next();
			 //System.out.println(b);
			 if(rs>0)
			 { 
				 System.out.println(adb.getItemid());
				 b1=true;
				 return b1;
			 }
			 
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b1;
	}
	}

