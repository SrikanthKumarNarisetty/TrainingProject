package com.bakery.daoimplementation;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bakery.DBUtility.DBhelper;

import com.bakery.beans.LoginBean;
import com.bakery.interfaces.LoginInterface;

public class Logindaoimplementation implements LoginInterface{
	

		
		boolean b1=false;

			
			public boolean validate(LoginBean lb)
			{
				try
				{
					Connection con=DBhelper.getConnection();
					 PreparedStatement stat=con.prepareStatement("select * from bak_login where user_id=? and password=?");
					// PreparedStatement stat1=con.prepareStatement("select * from bak_login where user_id=? and password=?");
					 stat.setString(1, lb.getName());
					 stat.setString(2,lb.getPassword());
					 ResultSet rs=stat.executeQuery();
					 boolean b=rs.next();
					 System.out.println(b);
					 if(b)
					 {
						 b1=true;
					 }
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				return b1;
			}
			
		

}
