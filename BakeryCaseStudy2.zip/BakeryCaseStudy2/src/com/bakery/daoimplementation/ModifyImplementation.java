package com.bakery.daoimplementation;

import java.sql.Connection;

import java.sql.PreparedStatement;

import com.bakery.DBUtility.DBhelper;
import com.bakery.beans.ModifyItemBean;

public class ModifyImplementation {

	public boolean modify(ModifyItemBean mib)
	{
		boolean b1=false;
		try
		{
			 Connection con=DBhelper.getConnection();
			 PreparedStatement stat=con.prepareStatement("update bak_item set avail_qty=avail_qty+? where item_id=?");
			// PreparedStatement stat1=con.prepareStatement("select * from bak_login where user_id=? and password=?");
			 stat.setString(2, mib.getItemid());
			 stat.setInt(1, mib.getQuantity());
			 int rs=stat.executeUpdate();
			 //boolean b=rs.next();
			 //System.out.println(b);
			 if(rs>0)
			 {
				 b1=true;
			 }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b1;
	}

}
