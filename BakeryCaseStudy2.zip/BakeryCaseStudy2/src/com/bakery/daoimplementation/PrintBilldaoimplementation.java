package com.bakery.daoimplementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bakery.DBUtility.DBhelper;
import com.bakery.beans.PrintBillBean;

public class PrintBilldaoimplementation {
		
	
		public boolean printBill(PrintBillBean pb) 
		{
			boolean b1=false;
				try
				{
				System.out.println("hello");
				Connection con1=DBhelper.getConnection();
				 PreparedStatement stat=con1.prepareStatement("select * from bill_details where user_id=?");
				 stat.setString(1,pb.getUsername());
				 ResultSet rs1=stat.executeQuery();
				
				 if(rs1.next())
				 {
					 b1=true;
					 String bill_id=rs1.getString(1);
					 pb.setBill_id(bill_id);
					 String bill_name=rs1.getString(2);
					 pb.setBill_name(bill_name);
					 String bill_contact=rs1.getString(3);
					 pb.setBill_contact(bill_contact);
					 String bill_address=rs1.getString(4);
					 pb.setBill_address(bill_address);
					 int bill_amount=rs1.getInt(5);
					 pb.setBill_amount(bill_amount);
				 }
				 }
				catch(Exception e)
				{
					System.out.println(e);
				}
		return b1;
		}

	}


