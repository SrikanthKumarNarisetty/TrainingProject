package com.bakery.daoimplementation;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bakery.DBUtility.DBhelper;

public class ViewCartdaoimplementation {

	
		String itemname;
		String quantity;
		int price;
		public String getItemname() {
			return itemname;
		}
		public void setItemname(String itemname) {
			this.itemname = itemname;
		}
		public String getQuantity() {
			return quantity;
		}
		public void setQuanity(String quantity) {
			this.quantity = quantity;
		}
		public int getPrice() {
			return price;
		}
		public void setPrice(int price) {
			this.price = price;
		}
		public boolean view()
		{	
			boolean b1=false;
			try
			{	
				System.out.println("hello");
				Connection con=DBhelper.getConnection();
				 PreparedStatement stat=con.prepareStatement(" select * from  cart where itemname=?");
				
				 stat.setString(1, itemname);
				 //stat.setString(2,quantity);
				 //stat.setInt(3, price);
				 
				 
				 //int  rs=stat.executeUpdate();
				 ResultSet r=stat.executeQuery();
				 boolean b=r.next();
				
				 if(b)
				 {
					 b1=true;
				 }
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			return b1;
			
		}

}
