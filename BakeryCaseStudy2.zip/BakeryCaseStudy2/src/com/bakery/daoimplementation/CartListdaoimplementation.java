package com.bakery.daoimplementation;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.bakery.DBUtility.DBhelper;
import com.bakery.beans.CartListBean;
import com.bakery.interfaces.CartListInterface;

public class CartListdaoimplementation implements CartListInterface{

		public boolean insert(CartListBean clb)
		{	
			
			boolean b1=false;
			try
			{	
				System.out.println("hello");
				 Connection con=DBhelper.getConnection();
				 PreparedStatement stat=con.prepareStatement(" insert into  cart(itemname,quantity,price,total,user_id) values(?,?,?,?,?)");
				int total=clb.getPrice()*clb.getQuantity();
				clb.setTotal(total);
				 stat.setString(1, clb.getItemname());
				 stat.setInt(2,clb.getQuantity());
				 stat.setInt(3, clb.getPrice());
				 stat.setInt(4, clb.getTotal());
				 stat.setString(5, clb.getUsername());
				 
				 int  rs=stat.executeUpdate();
				System.out.println(rs);
				 if(rs>0)
				 {
					 b1=true;
				 }
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			return b1;
			
		}

		
		


}
