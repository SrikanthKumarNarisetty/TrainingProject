package com.bakery.daoimplementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bakery.DBUtility.DBhelper;
import com.bakery.beans.AddCartBean;
import com.bakery.interfaces.AddCartInterface;


public class Addcartdaoimplementation implements AddCartInterface{
	public boolean chechForAvail(AddCartBean acb)
	{
		boolean b1=false;
		try
		{
			Connection con=DBhelper.getConnection();
			 PreparedStatement stat=con.prepareStatement("select * from bak_item where item_id=? and avail_qty>=?");
			 stat.setString(1,acb.getItemid());
			 stat.setInt(2,acb.getQuantity());
			 ResultSet rs=stat.executeQuery();
			 boolean b=rs.next();
			 System.out.println(b);
			 System.out.println(acb.getItemid());
			 System.out.println(acb.getQuantity());
				 if(b)
				 {
					 b1=true;
				 }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println(b1);
		return b1;
	}

	
}
