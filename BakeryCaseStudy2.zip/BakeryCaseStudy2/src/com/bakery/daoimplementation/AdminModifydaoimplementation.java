package com.bakery.daoimplementation;
import java.sql.PreparedStatement;

import java.sql.Connection;

import com.bakery.DBUtility.DBhelper;

public class AdminModifydaoimplementation {

		
		String itemid;
		int quantity;

		public int getQuantity() {
			return quantity;
		}

		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}

		public String getItemid() {
			return itemid;
		}

		public void setItemid(String itemid) {
			this.itemid = itemid;
		}
		public boolean modify()
		{
			boolean b1=false;
			try
			{
				 Connection con=DBhelper.getConnection();
				 PreparedStatement stat=con.prepareStatement("update bak_item set avail_qty=avail_qty+? where item_id=?");
				// PreparedStatement stat1=con.prepareStatement("select * from bak_login where user_id=? and password=?");
				 stat.setString(2, itemid);
				 stat.setInt(1, quantity);
				 int rs=stat.executeUpdate();
				 //boolean b=rs.next();
				 //System.out.println(b);
				 if(rs>0)
				 {
					 b1=true;
				 }
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			return b1;
		}
		


}
