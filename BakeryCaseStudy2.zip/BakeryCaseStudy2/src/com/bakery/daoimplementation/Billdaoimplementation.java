package com.bakery.daoimplementation;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bakery.DBUtility.DBhelper;
import com.bakery.beans.BillingBean;
import com.bakery.interfaces.BillingInterface;

public class Billdaoimplementation implements BillingInterface {
		public boolean bill_details(BillingBean bb)
		{	
			boolean b1=false;
			try
			{	
				System.out.println("hello");
				 Connection con1=DBhelper.getConnection();
				 PreparedStatement stat=con1.prepareStatement("select sum(total) as bill_amount from cart where user_id=?");
				 stat.setString(1,bb.getUsername());
				 ResultSet rs1=stat.executeQuery();
				 rs1.next();
				 int bamount=rs1.getInt(1);
				 con1.close();
				 Connection con2=DBhelper.getConnection();
				 PreparedStatement stat1=con2.prepareStatement("insert into bill_details(bill_id,bill_name,bill_contact,bill_address,bill_amount,bill_date,user_id) values(billid.nextval,?,?,?,?,sysdate,?)");
				
				 stat1.setString(1,bb.getBill_name());
				 stat1.setString(2,bb.getBill_contact());
				 stat1.setString(3,bb.getBill_address());
				 stat1.setInt(4,bamount);
				 stat1.setString(5,bb.getUsername());
				 int rs=stat1.executeUpdate();
				 if(rs>0)
				 {
					 b1=true;
					 System.out.println("Successful");
				 }
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			return b1;
		}
		
	
		


}
