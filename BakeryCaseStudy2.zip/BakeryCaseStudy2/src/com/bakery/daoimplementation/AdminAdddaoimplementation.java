package com.bakery.daoimplementation;
import java.sql.Connection;

import java.sql.PreparedStatement;
//import java.sql.ResultSet;

import com.bakery.DBUtility.DBhelper;
import com.bakery.beans.AdminAddBean;

public class AdminAdddaoimplementation {
	
	public boolean add(AdminAddBean aab)
	{ 	
		boolean b1=false;
		try
		{
			 Connection con=DBhelper.getConnection();
			 PreparedStatement stat=con.prepareStatement("insert into bak_item values(?,?,?,?)");
			// PreparedStatement stat1=con.prepareStatement("select * from bak_login where user_id=? and password=?");
			 stat.setString(1, aab.getItemid());
			 stat.setString(2, aab.getItemname());
			 stat.setInt(3,aab.getPrice());
			 stat.setInt(4,aab.getAvail_quantity());
			 int rs=stat.executeUpdate();
			 //boolean b=rs.next();
			 //System.out.println(b);
			 if(rs>0)
			 {
				 b1=true;
			 }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b1;
	}
}




