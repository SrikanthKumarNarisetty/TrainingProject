package com.bakery.daoimplementation;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bakery.DBUtility.DBhelper;
import com.bakery.beans.OrderItemsBean;

public class Orderdaoimplementation {
		

		public boolean order(OrderItemsBean order)
		{	
			boolean b1=false;
			try
			{	
				Connection con=DBhelper.getConnection();
				 PreparedStatement stat=con.prepareStatement("select itemname,quantity*price as totalamount from  cart where itemname=?");
				
				 stat.setString(1, order.getItemname());
				 //stat.setString(2,quantity);
				 //stat.setInt(3, price);
				 
				 
				 //int  rs=stat.executeUpdate();
				 ResultSet r=stat.executeQuery();
				 //boolean b=r.next();
				
				 if(r.next())
				 {
					 System.out.println(r.getString(1));
					 b1=true;
				 }
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			return b1;
			
		}


}
