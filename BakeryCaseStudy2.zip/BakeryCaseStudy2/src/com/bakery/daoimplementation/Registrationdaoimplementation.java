package com.bakery.daoimplementation;

import java.sql.Connection;

import java.sql.PreparedStatement;

import com.bakery.DBUtility.DBhelper;

import com.bakery.beans.RegistrationBean;

public class Registrationdaoimplementation {
		
		public boolean insert(RegistrationBean rb)
		{	
			boolean b1=false;
			try
			{	
				Connection con=DBhelper.getConnection();
				 PreparedStatement stat=con.prepareStatement(" insert into  bak_login(name,dob,email,contact,address,user_id,password) values(?,?,?,?,?,?,?)");
				
				 stat.setString(1, rb.getName());
				 stat.setString(2, rb.getDOB());
				 stat.setString(3, rb.getEmail());
				 stat.setString(4, rb.getContact());
				 stat.setString(5, rb.getAddress());
				 stat.setString(6, rb.getUsername());
				 stat.setString(7, rb.getPassword());
				 
				 int  rs=stat.executeUpdate();
				
				 if(rs>0)
				 {
					 b1=true;
				 }
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			return b1;
			
		}

	}


