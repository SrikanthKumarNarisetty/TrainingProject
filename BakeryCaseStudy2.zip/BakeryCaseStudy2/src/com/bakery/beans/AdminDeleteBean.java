package com.bakery.beans;




public class AdminDeleteBean {
	
	String itemid;

	public String getItemid() {
		return itemid;
	}

	public void setItemid(String itemid) {
		this.itemid = itemid;
	}
	
	}

