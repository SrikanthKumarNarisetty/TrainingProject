package com.bakery.beans;

public class AdminModify {		
		String itemid;

		public String getItemid() {
			return itemid;
		}

		public void setItemid(String itemid) {
			this.itemid = itemid;
		}
	/*	public boolean delete()
		{
			boolean b1=false;
			try
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				 Connection con=DriverManager.getConnection("jdbc:oracle:thin:@hstslc015.mahindrasatyam.ad:1521:elp","ELITE1805", "techM123$");
				 PreparedStatement stat=con.prepareStatement("delete from bak_item where item_id=?");
				// PreparedStatement stat1=con.prepareStatement("select * from bak_login where user_id=? and password=?");
				 stat.setString(1, itemid);
				
				 int rs=stat.executeUpdate();
				 System.out.println(itemid);
				 //boolean b=rs.next();
				 //System.out.println(b);
				 if(rs>0)
				 { 
					 System.out.println(itemid);
					 b1=true;
					 return b1;
				 }
				 
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			return b1;
		}
		} */


}
