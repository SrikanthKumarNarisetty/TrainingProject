package com.bakery.beans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class RegistrationBean {
	private String name,DOB,email,address,username,password;
	private String contact;
		
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDOB() {
		return DOB;
	}


	public void setDOB(String dOB) {
		DOB = dOB;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getContact() {
		return contact;
	}


	public void setContact(String contact) {
		this.contact = contact;
	}


	public boolean insert()
	{	
		boolean b1=false;
		try
		{	
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@hstslc015.mahindrasatyam.ad:1521:elp","ELITE1805", "techM123$");
			 PreparedStatement stat=con.prepareStatement(" insert into  bak_login(name,dob,email,contact,address,user_id,password) values(?,?,?,?,?,?,?)");
			
			 stat.setString(1, name);
			 stat.setString(2, DOB);
			 stat.setString(3, email);
			 stat.setString(4, contact);
			 stat.setString(5, address);
			 stat.setString(6, username);
			 stat.setString(7, password);
			 
			 int  rs=stat.executeUpdate();
			
			 if(rs>0)
			 {
				 b1=true;
			 }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b1;
		
	}

}
