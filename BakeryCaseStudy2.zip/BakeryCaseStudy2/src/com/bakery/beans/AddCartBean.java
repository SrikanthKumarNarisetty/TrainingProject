package com.bakery.beans;
public class AddCartBean {
	private String itemid;
	private int quantity;
	
	
	public String getItemid() {
		return itemid;
	}


	public void setItemid(String itemid) {
		this.itemid = itemid;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	/*public boolean chechForAvail()
	{
		try
		{
			Connection con=DBhelper.getConnection();
			 PreparedStatement stat=con.prepareStatement("select * from bak_item where item_id=? and avail_qty>=?");
			 stat.setString(1,itemid);
			 stat.setInt(2,quantity);
			 ResultSet rs=stat.executeQuery();
			 boolean b=rs.next();
			 System.out.println(b);
			 System.out.println(itemid);
			 System.out.println(quantity);
				 if(b)
				 {
					 b1=true;
				 }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println(b1);
		return b1;
	}
	*/
}