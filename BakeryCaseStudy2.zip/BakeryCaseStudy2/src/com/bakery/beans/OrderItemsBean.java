package com.bakery.beans;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class OrderItemsBean {
	
	String itemname;
	int quantity;
	int price;
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public boolean order()
	{	
		boolean b1=false;
		try
		{	
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@hstslc015.mahindrasatyam.ad:1521:elp","ELITE1805", "techM123$");
			 PreparedStatement stat=con.prepareStatement("select itemname,quantity*price as totalamount from  cart where itemname=?");
			
			 stat.setString(1, itemname);
			 //stat.setString(2,quantity);
			 //stat.setInt(3, price);
			 
			 
			 //int  rs=stat.executeUpdate();
			 ResultSet r=stat.executeQuery();
			 //boolean b=r.next();
			
			 if(r.next())
			 {
				 System.out.println(r.getString(1));
				 b1=true;
			 }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b1;
		
	}
}
