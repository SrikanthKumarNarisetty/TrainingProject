package com.bakery.beans;

public class AdminAddBean {
		String itemid,itemname;
		int price,avail_quantity;
		public String getItemid() {
			return itemid;
		}
		public void setItemid(String itemid) {
			this.itemid = itemid;
		}
		public String getItemname() {
			return itemname;
		}
		public void setItemname(String itemname) {
			this.itemname = itemname;
		}
		public int getPrice() {
			return price;
		}
		public void setPrice(int price) {
			this.price = price;
		}
		public int getAvail_quantity() {
			return avail_quantity;
		}
		public void setAvail_quantity(int avail_quantity) {
			this.avail_quantity = avail_quantity;
		}
		/*public boolean add()
		{ 	
			boolean b1=false;
			try
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				 Connection con=DriverManager.getConnection("jdbc:oracle:thin:@hstslc015.mahindrasatyam.ad:1521:elp","ELITE1805", "techM123$");
				 PreparedStatement stat=con.prepareStatement("insert into bak_item values(?,?,?,?)");
				// PreparedStatement stat1=con.prepareStatement("select * from bak_login where user_id=? and password=?");
				 stat.setString(1, itemid);
				 stat.setString(2, itemname);
				 stat.setInt(3,price);
				 stat.setInt(4,avail_quantity);
				 int rs=stat.executeUpdate();
				 //boolean b=rs.next();
				 //System.out.println(b);
				 if(rs>0)
				 {
					 b1=true;
				 }
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			return b1;
		}*/
	}

