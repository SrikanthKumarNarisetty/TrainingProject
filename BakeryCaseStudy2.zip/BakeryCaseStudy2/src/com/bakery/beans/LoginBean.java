package com.bakery.beans;



public class LoginBean {

	
	boolean b1=false;

		private String name,password;
		
		

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}
		/*public boolean validate()
		{
			try
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@hstslc015.mahindrasatyam.ad:1521:elp","ELITE1805", "techM123$");
				 PreparedStatement stat=con.prepareStatement("select * from bak_login where user_id=? and password=?");
				// PreparedStatement stat1=con.prepareStatement("select * from bak_login where user_id=? and password=?");
				 stat.setString(1, name);
				 stat.setString(2, password);
				 ResultSet rs=stat.executeQuery();
				 boolean b=rs.next();
				 System.out.println(b);
				 if(b)
				 {
					 b1=true;
				 }
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			return b1;
		}
		*/
	}

	

