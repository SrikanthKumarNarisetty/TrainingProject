package com.bakery.beans;


public class CartListBean {
	String itemname;
	String username;
	int quantity;
	int price;
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	int total;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuanity(int quantity) {
		this.quantity = quantity;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	/*public boolean insert()
	{	
		total=price*quantity;
		boolean b1=false;
		try
		{	
			System.out.println("hello");
			 Connection con=DriverManager.getConnection("jdbc:oracle:thin:@hstslc015.mahindrasatyam.ad:1521:elp","ELITE1805", "techM123$");
			 PreparedStatement stat=con.prepareStatement(" insert into  cart(itemname,quantity,price,total,user_id) values(?,?,?,?,?)");
			
			 stat.setString(1, itemname);
			 stat.setInt(2,quantity);
			 stat.setInt(3, price);
			 stat.setInt(4, total);
			 stat.setString(5, username);
			 
			 int  rs=stat.executeUpdate();
			
			 if(rs>0)
			 {
				 b1=true;
			 }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b1;
		
	}
*/
	}
	

