package com.bakery.beans;



//import java.sql.SQLException;

public class BillingBean {
	String bill_id,bill_name,bill_address,bill_contact;
	int bill_amount;
	String bill_date;
	String username;
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getBill_id() {
		return bill_id;
	}

	public void setBill_id(String bill_id) {
		this.bill_id = bill_id;
	}

	public String getBill_name() {
		return bill_name;
	}

	public void setBill_name(String bill_name) {
		this.bill_name = bill_name;
	}

	public String getBill_address() {
		return bill_address;
	}

	public void setBill_address(String bill_address) {
		this.bill_address = bill_address;
	}

	public String getBill_contact() {
		return bill_contact;
	}

	public void setBill_contact(String bill_contact) {
		this.bill_contact = bill_contact;
	}

	public int getBill_amount() {
		return bill_amount;
	}

	public void setBill_amount(int bill_amount) {
		this.bill_amount = bill_amount;
	}

	public String getBill_date() {
		return bill_date;
	}

	public void setBill_date(String bill_date) {
		this.bill_date = bill_date;
	}

	/*public boolean bill_details()
	{	
		boolean b1=false;
		try
		{	
			System.out.println("hello");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@hstslc015.mahindrasatyam.ad:1521:elp","ELITE1805", "techM123$");
			 PreparedStatement stat=con1.prepareStatement("select sum(total) as bill_amount from cart where user_id=?");
			 stat.setString(1,username);
			 ResultSet rs1=stat.executeQuery();
			 rs1.next();
			 int bamount=rs1.getInt(1);
			 con1.close();
			 Connection con2=DriverManager.getConnection("jdbc:oracle:thin:@hstslc015.mahindrasatyam.ad:1521:elp","ELITE1805", "techM123$");
			 PreparedStatement stat1=con2.prepareStatement("insert into bill_details(bill_id,bill_name,bill_contact,bill_address,bill_amount,bill_date,user_id) values(billid.nextval,?,?,?,?,sysdate,?)");
			
			 stat1.setString(1,bill_name);
			 stat1.setString(2,bill_contact);
			 stat1.setString(3,bill_address);
			 stat1.setInt(4,bamount);
			 stat1.setString(5,username);
			 int rs=stat1.executeUpdate();
			 if(rs>0)
			 {
				 b1=true;
				 System.out.println("Successful");
			 }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b1;
	}*/
	
	}
	

