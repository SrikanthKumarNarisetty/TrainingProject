package com.bakery.beans;



public class PrintBillBean {
	
	String bill_id,bill_date,bill_name,bill_contact,bill_address,username;
	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	int bill_amount;
	
	
	public String getBill_id() {
		return bill_id;
	}


	public void setBill_id(String bill_id) {
		this.bill_id = bill_id;
	}


	public String getBill_date() {
		return bill_date;
	}


	public void setBill_date(String bill_date) {
		this.bill_date = bill_date;
	}


	public String getBill_name() {
		return bill_name;
	}


	public void setBill_name(String bill_name) {
		this.bill_name = bill_name;
	}


	public String getBill_contact() {
		return bill_contact;
	}


	public void setBill_contact(String bill_contact) {
		this.bill_contact = bill_contact;
	}


	public String getBill_address() {
		return bill_address;
	}


	public void setBill_address(String bill_address) {
		this.bill_address = bill_address;
	}


	public int getBill_amount() {
		return bill_amount;
	}


	public void setBill_amount(int bill_amount) {
		this.bill_amount = bill_amount;
	}


	/*public boolean printBill() 
	{
		boolean b1=false;
			try
			{
			System.out.println(username);
			System.out.println("hello");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con1=DriverManager.getConnection("jdbc:oracle:thin:@hstslc015.mahindrasatyam.ad:1521:elp","ELITE1805", "techM123$");
			 PreparedStatement stat=con1.prepareStatement("select * from bill_details where user_id=?");
			 stat.setString(1,username);
			 ResultSet rs1=stat.executeQuery();
			
			 if(rs1.next())
			 {
				 b1=true;
				 bill_id=rs1.getString(1);
				 bill_name=rs1.getString(2);
				 bill_contact=rs1.getString(3);
				 bill_address=rs1.getString(4);
				 bill_amount=rs1.getInt(5); 
			 }
			 }
			catch(Exception e)
			{
				System.out.println(e);
			}
	return b1;
	}
*/
}
