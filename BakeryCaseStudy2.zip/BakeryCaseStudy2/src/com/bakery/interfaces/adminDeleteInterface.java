package com.bakery.interfaces;

import com.bakery.beans.AdminDeleteBean;

public interface adminDeleteInterface {
	public boolean delete(AdminDeleteBean adb);
}
