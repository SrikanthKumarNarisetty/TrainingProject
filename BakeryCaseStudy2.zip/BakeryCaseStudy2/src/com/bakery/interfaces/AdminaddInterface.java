package com.bakery.interfaces;

import com.bakery.beans.AdminAddBean;

public interface AdminaddInterface {
	public boolean add(AdminAddBean aab);
}
