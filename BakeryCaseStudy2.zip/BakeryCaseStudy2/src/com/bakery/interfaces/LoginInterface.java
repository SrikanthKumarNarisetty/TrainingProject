package com.bakery.interfaces;

import com.bakery.beans.LoginBean;

public interface LoginInterface {
	public boolean validate(LoginBean lb);
}
