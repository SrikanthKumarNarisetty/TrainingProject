package com.bakery.interfaces;

import com.bakery.beans.OrderItemsBean;

public interface OrderItemsInterface {
	public boolean order(OrderItemsBean order);
}
