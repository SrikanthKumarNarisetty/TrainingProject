package com.bakery.interfaces;

import com.bakery.beans.RegistrationBean;

public interface RegisterInterface {
	public boolean insert(RegistrationBean rb);
}
