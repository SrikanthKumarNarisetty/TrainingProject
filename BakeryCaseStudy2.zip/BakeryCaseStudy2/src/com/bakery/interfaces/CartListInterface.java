package com.bakery.interfaces;

import com.bakery.beans.CartListBean;

public interface CartListInterface {
	public boolean insert(CartListBean clb);
}
