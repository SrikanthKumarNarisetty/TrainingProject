package com.bakery.interfaces;

import com.bakery.beans.AddCartBean;



public interface AddCartInterface {
	public boolean chechForAvail(AddCartBean acb);
}
