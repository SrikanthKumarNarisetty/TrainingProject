package com.bakery.interfaces;

import com.bakery.beans.BillingBean;

public interface BillingInterface {
	public boolean bill_details(BillingBean bb);
}
