package com.bakery.interfaces;

import com.bakery.beans.PrintBillBean;

public interface PrintBillInterface {
	boolean printBill(PrintBillBean pb);
}
